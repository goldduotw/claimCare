
import { getApp } from "firebase/app";
import { getStripePayments, createCheckoutSession, type StripePayments } from "@invertase/firestore-stripe-payments";

let payments: StripePayments | null = null;

const getPayments = () => {
  if (!payments) {
    payments = getStripePayments(getApp(), {
      productsCollection: "products",
      customersCollection: "customers",
    });
  }
  return payments;
}

// Updated src/stripe.ts
export const startPayment = async (auditId: string) => { // 1. Accept auditId here
  const paymentsInstance = getPayments();
  const session = await createCheckoutSession(paymentsInstance, {
    price: STRIPE_PRICE_ID, 
    // 2. Fix the success_url (closing brace for session_id)
    success_url: `https://goldduo.com/success?session_id={CHECKOUT_SESSION_ID}&auditId=${auditId}`,
    cancel_url: `https://goldduo.com/`,
    // 3. ADD THIS METADATA BLOCK
    metadata: {
      auditId: auditId // This tells the Firebase Extension which doc to update
    }
  });
  window.location.assign(session.url);
};

//export const STRIPE_PRICE_ID = 'price_1SouyhF1JPfHP5JnjUOQB6aM';    
export const STRIPE_PRICE_ID = 'price_1SpgLYF1JPfHP5JnkoIJ5Oyv';