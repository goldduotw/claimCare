"use client";

import { useState, useMemo, useRef, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Lock, Share, User, Loader2, AlertCircle } from "lucide-react"; // Added AlertCircle
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert"; // Added Alert
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { useToast } from "@/hooks/use-toast";
import { useFirestore } from "@/firebase/provider";
import { useUser } from "@/firebase/auth/use-user";
import { onSnapshot, collection, addDoc, doc } from "firebase/firestore";
import Confetti from 'react-confetti';
import { STRIPE_PRICE_ID } from '@/stripe';

export type DiscrepancyDetails = {
    patientName?: string;
    expectedAmount?: string;
    billedAmount?: string;
    planReference?: string;
}

type ReceptionistViewModalProps = {
  isOpen: boolean;
  onClose: () => void;
  details: DiscrepancyDetails;
  analysisTable: string;
  auditId?: string; 
};

function parseMarkdownTable(markdown: string): { headers: string[], rows: string[][] } {
    if (!markdown || !markdown.trim()) return { headers: [], rows: [] };
    const lines = markdown.trim().split('\n');
    const headerLineIndex = lines.findIndex(line => line.includes('|'));
    if (headerLineIndex === -1) return { headers: [], rows: [] };
    
    const headers = lines[headerLineIndex].split('|').map(h => h.trim()).filter(Boolean);
    const rows = lines.slice(headerLineIndex + 2)
        .filter(line => line.includes('|') && !line.includes('---'))
        .map(line => line.split('|').map(cell => cell.trim()).filter(Boolean));
    return { headers, rows };
}

export function ReceptionistViewModal({ isOpen, onClose, details, analysisTable, auditId }: ReceptionistViewModalProps) {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'paid'>('pending');
  const [isLoadingStatus, setIsLoadingStatus] = useState(true);

  const { user, signInWithGoogle, loading: isAuthLoading } = useUser();
  const { toast } = useToast();
  const firestore = useFirestore();
  const modalContentRef = useRef<HTMLDivElement>(null);
  const hasAnnouncedSuccess = useRef(false);

  const { headers, rows } = useMemo(() => parseMarkdownTable(analysisTable), [analysisTable]);

  const billed = parseFloat(details.billedAmount?.replace(/[$,]/g, "") || "0");
  const expected = parseFloat(details.expectedAmount?.replace(/[$,]/g, "") || "0");
  const savings = billed - expected;

  useEffect(() => {
    if (!isOpen) {
        hasAnnouncedSuccess.current = false;
        setIsLoadingStatus(true);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!user) {
        setPaymentStatus('pending');
        setIsLoadingStatus(false);
        return;
    }
    if (!isOpen || !firestore) return;
    setIsLoadingStatus(true);

    const handleUnlock = (status: string, isSilent: boolean) => {
      if (status === 'paid') {
        setPaymentStatus('paid');
        setIsLoadingStatus(false);
        if (!isSilent && !hasAnnouncedSuccess.current) {
          setShowConfetti(true);
          hasAnnouncedSuccess.current = true;
          setTimeout(() => setShowConfetti(false), 5000);
        } else {
          hasAnnouncedSuccess.current = true;
        }
      }
    };

    const unsubSub = onSnapshot(collection(firestore, 'customers', user.uid, 'subscriptions'), (snapshot) => {
      const hasPro = snapshot.docs.some(doc => doc.data().status === 'active');
      if (hasPro) handleUnlock('paid', true); 
      else if (!auditId) setIsLoadingStatus(false);
    });

    let unsubAudit = () => {};
    if (auditId) {
      unsubAudit = onSnapshot(doc(firestore, 'audits', auditId), (snap) => {
        const data = snap.data();
        if (data?.status === 'paid') handleUnlock('paid', false); 
        else {
          setPaymentStatus('pending');
          setIsLoadingStatus(false);
        }
      }, (err) => { setIsLoadingStatus(false); });
    }
    return () => { unsubSub(); unsubAudit(); };
  }, [isOpen, user, firestore, auditId]);

  const handleGoogleSignIn = () => {
    localStorage.setItem('pending_audit_data', JSON.stringify({ details, analysisTable, auditId }));
    signInWithGoogle();
  };

  const handleCheckout = async () => {
    if (!user || !firestore || !auditId) return;
    setIsCheckingOut(true);
    try {
        const sessionDocRef = await addDoc(collection(firestore, 'customers', user.uid, 'checkout_sessions'), {
            price: STRIPE_PRICE_ID,
            success_url: window.location.href,
            cancel_url: window.location.href,
            metadata: { auditId: auditId } 
        });
        onSnapshot(sessionDocRef, (snap) => {
          const data = snap.data();
          if (data?.url) window.location.assign(data.url);
          else if (data?.error) {
            toast({ variant: "destructive", title: "Stripe Error", description: data.error.message });
            setIsCheckingOut(false);
          }
        });
    } catch (e) { setIsCheckingOut(false); }
  };

  const handleSaveToPhone = async () => {
    if (paymentStatus !== 'paid' || !modalContentRef.current) return;
    const canvas = await html2canvas(modalContentRef.current, { scale: 2, backgroundColor: '#ffffff' });
    const pdf = new jsPDF('p', 'mm', 'a4');
    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 10, 10, 190, (190 * canvas.height) / canvas.width);
    pdf.save(`Audit_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  const isUnlocked = paymentStatus === 'paid';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl bg-white text-gray-900 max-h-[90vh] overflow-y-auto">
        {showConfetti && <Confetti recycle={false} numberOfPieces={500} gravity={0.2} />}
        
        <div className="relative">
            <div ref={modalContentRef} className={`p-8 transition-all duration-1000 ${!isUnlocked ? 'blur-2xl pointer-events-none scale-95 opacity-50' : 'blur-0 scale-100 opacity-100'}`}>
                <DialogHeader>
                    <DialogTitle className="text-xl font-bold text-center text-blue-900">Patient Advocacy Report</DialogTitle>
                    <p className="text-center text-sm text-gray-500">Verified for {details.patientName || "the Patient"}</p>
                </DialogHeader>

                <div className="my-6 border-4 border-dashed border-green-500 rounded-xl p-6 bg-green-50 text-center">
                    <div className="flex justify-center gap-12">
                        <div>
                            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold">Fair Price</p>
                            <p className="text-3xl font-black text-green-600">{details.expectedAmount}</p>
                        </div>
                        <div className="border-r border-gray-200"></div>
                        <div>
                            <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold">Billed Amount</p>
                            <p className="text-3xl font-black text-red-500">{details.billedAmount}</p>
                        </div>
                    </div>
                </div>

                {/* --- DISCLAIMER ADDED HERE --- */}
                <Alert className="mb-6 bg-amber-50 border-amber-200 text-amber-800">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-xs">
                    <strong>Disclaimer:</strong> This AI-generated audit is approximately 80% accurate. Please review these findings with your provider or insurance representative before making any payment decisions.
                  </AlertDescription>
                </Alert>

                <div className="border rounded-xl overflow-hidden shadow-sm">
                    <Table>
                        <TableHeader className="bg-gray-50">
                            <TableRow>
                                {headers.map((h, i) => <TableHead key={i} className="font-bold text-gray-700">{h}</TableHead>)}
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {rows.map((row, ri) => (
                                <TableRow key={ri} className="hover:bg-blue-50/30 transition-colors">
                                    {row.map((c, ci) => <TableCell key={ci} className="py-4">{c}</TableCell>)}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </div>

            {!isUnlocked && (
                 <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-6 bg-white/10">
                    {isAuthLoading || isLoadingStatus ? (
                        <div className="bg-white p-8 rounded-2xl shadow-xl flex flex-col items-center">
                            <Loader2 className="h-8 w-8 animate-spin text-blue-600 mb-2" />
                            <p className="text-sm font-medium text-gray-500">Verifying access...</p>
                        </div>
                    ) : (
                        <div className="animate-in fade-in zoom-in duration-500 flex flex-col items-center bg-white p-10 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.2)] border border-gray-100 max-w-sm">
                            <div className="bg-blue-50 p-4 rounded-full mb-4">
                                <Lock className="h-8 w-8 text-blue-600" />
                            </div>
                            {!user ? (
                                <>
                                    <h3 className="text-2xl font-black mb-2 text-gray-800">Sign In Required</h3>
                                    <p className="text-gray-500 mb-6 text-sm text-center">Please sign in with Google to securely save and unlock your audit.</p>
                                    <Button size="lg" className="bg-gray-900 w-full" onClick={handleGoogleSignIn}>
                                        <User className="mr-2 h-4 w-4" /> Sign In with Google
                                    </Button>
                                </>
                            ) : (
                                <>
                                    <h3 className="text-2xl font-black mb-2 text-gray-800 text-center">Locked Report</h3>
                                    <p className="text-gray-500 mb-6 text-sm text-center">Unlock this report to see the fair price and save ${savings.toFixed(2)}.</p>
                                    <Button size="lg" className="bg-green-600 hover:bg-green-700 w-full font-bold py-6 text-lg shadow-lg shadow-green-200" onClick={handleCheckout} disabled={isCheckingOut}>
                                        {isCheckingOut ? "Connecting..." : `Unlock for $85`}
                                    </Button>
                                </>
                            )}
                        </div>
                    )}
                 </div>
            )}
        </div>

        <DialogFooter className="px-8 pb-8 pt-4 gap-2">
            <Button variant="outline" className="flex-1" onClick={handleSaveToPhone} disabled={!isUnlocked}>
                <Share className="mr-2 h-4 w-4" /> Export PDF
            </Button>
            <DialogClose asChild>
                <Button variant="ghost" className="flex-1">Close</Button>
            </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}