
"use client";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "./ui/button";

type ComplianceModalProps = {
  isOpen: boolean;
  onAgree: () => void;
};

export function ComplianceModal({ isOpen, onAgree }: ComplianceModalProps) {
  return (
    <AlertDialog open={isOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Compliance Guardrail</AlertDialogTitle>
          <AlertDialogDescription>
            This is a Prototype for educational use only. I agree not to upload Social Security Numbers or Full Names. I understand this tool provides AI-generated suggestions, not medical or legal advice.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogAction asChild>
            <Button onClick={onAgree}>I Agree</Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
