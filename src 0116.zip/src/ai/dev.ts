import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-medical-bill-for-errors.ts';
import '@/ai/flows/display-potential-savings.ts';