"use server";

import { analyzeMedicalBillForErrors, AnalyzeMedicalBillForErrorsInput, AnalyzeMedicalBillForErrorsOutput } from '@/ai/flows/analyze-medical-bill-for-errors';
import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getStorage, ref, deleteObject } from 'firebase/storage';
import { firebaseConfig } from '@/firebase/config';

// Server-side Firebase initialization
let app: FirebaseApp;
if (getApps().length === 0) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}
const storage = getStorage(app);

export async function analyzeBill(input: AnalyzeMedicalBillForErrorsInput): Promise<{ success: true; data: AnalyzeMedicalBillForErrorsOutput } | { success: false; error: string }> {
  if (!input.billText?.trim() && !input.imageData) {
    return { success: false, error: "Please provide either bill text or an image of the bill." };
  }
  
  if (input.billText && input.billText.trim().length < 50) {
     return { success: false, error: "Please provide more detailed bill text for an accurate analysis." };
  }

  try {
    const result = await analyzeMedicalBillForErrors(input);
    return { success: true, data: result };
  } catch (e: any) {
    console.error(e);
    const errorMessage = e.message || "An unexpected error occurred during analysis. Please try again later.";
    return { success: false, error: errorMessage };
  } finally {
    if (input.imageData && input.imageData.startsWith('gs://')) {
        try {
            const storageRef = ref(storage, input.imageData);
            await deleteObject(storageRef);
            console.log("Image deleted from Firebase Storage:", input.imageData);
        } catch (deleteError: any) {
            // Log the error, but don't fail the entire operation if deletion fails.
            // The user has their result, which is the most important part.
            console.error("Failed to delete image from storage:", deleteError);
        }
    }
  }
}
