"use client";

import { createContext, useContext, ReactNode } from 'react';
import { Auth } from 'firebase/auth';
import { Firestore } from 'firebase/firestore';
import { FirebaseStorage } from 'firebase/storage';
import { FirebaseApp } from 'firebase/app';
import { app, auth, firestore, storage } from './client';

type FirebaseContextValue = {
  app: FirebaseApp;
  auth: Auth;
  firestore: Firestore;
  storage: FirebaseStorage;
};

const FirebaseContext = createContext<FirebaseContextValue | undefined>(undefined);

export const FirebaseClientProvider = ({ children }: { children: ReactNode }) => {
  const services = { app, auth, firestore, storage };

  return (
    <FirebaseContext.Provider value={services}>
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = (): FirebaseContextValue => {
  const context = useContext(FirebaseContext);
  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseClientProvider');
  }
  return context;
};

export const useAuth = (): Auth => {
  const { auth } = useFirebase();
  return auth;
};
export const useFirestore = (): Firestore => {
  const { firestore } = useFirebase();
  return firestore;
};
export const useStorage = (): FirebaseStorage => {
  const { storage } = useFirebase();
  return storage;
};
