
"use client";

import { useEffect, useState, useMemo } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { useAuth, useFirestore } from '../provider';
import {
  GoogleAuthProvider,
  signInWithRedirect,
  getRedirectResult,
  signOut as firebaseSignOut,
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';


export const useUser = () => {
  const auth = useAuth();
  const firestore = useFirestore();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Memoize the provider to prevent re-creation on every render
  const provider = useMemo(() => new GoogleAuthProvider(), []);

  useEffect(() => {
    if (!auth) {
      // Auth service might not be ready on initial render, wait for it.
      return;
    }
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });

    // Check for redirect result on initial load
    getRedirectResult(auth)
      .then(async (result) => {
        if (result && result.user && firestore) {
          const user = result.user;
          // Create a customer document in Firestore
          await setDoc(doc(firestore, "customers", user.uid), {
            email: user.email,
            stripeId: null,
          }, { merge: true });
          setUser(user);
        }
      })
      .catch((error) => {
        console.error("Error getting redirect result: ", error);
      })
      .finally(() => {
        setLoading(false);
      });

    return () => unsubscribe();
  }, [auth, firestore, provider]);

  const signInWithGoogle = async () => {
    if (!auth) return;
    setLoading(true);
    try {
      // We no longer wait for a result here, the page will redirect
      await signInWithRedirect(auth, provider);
    } catch (error) {
      console.error("Error signing in with Google: ", error);
      setLoading(false);
    }
  };

  const signOut = async () => {
    if (!auth) return;
    try {
      await firebaseSignOut(auth);
      setUser(null);
    } catch (error) {
      console.error("Error signing out: ", error);
    }
  };


  return { user, loading, signInWithGoogle, signOut };
};
