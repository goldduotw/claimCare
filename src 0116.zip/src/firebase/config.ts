// src/firebase/config.ts
import { initializeApp, getApps } from "firebase/app";
import { getFirestore } from "firebase/firestore"; // Import this!

// It's safe to expose this configuration to the client-side.
// The app's security is enforced by Firebase Security Rules.
export const firebaseConfig = {
  projectId: "studio-1043378437-64ed0",
  appId: "1:741961096374:web:2d115d4474bfd3bede5a17",
  apiKey: "AIzaSyCLxCmYMBkD9BaPPLmrKshOklrOf-EUZ9Y",
  authDomain: "goldduo.com",
  measurementId: "",
  messagingSenderId: "741961096374",
  storageBucket: "studio-1043378437-64ed0.firebasestorage.app",
};

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Initialize and EXPORT the database as 'db'
export const db = getFirestore(app);    
